
export default {
  bootstrap: () => import('./main.server.mjs').then(m => m.default),
  inlineCriticalCss: true,
  baseHref: '/',
  locale: undefined,
  routes: [
  {
    "renderMode": 2,
    "route": "/dashboard"
  },
  {
    "renderMode": 2,
    "route": "/dashboard/survey"
  },
  {
    "renderMode": 2,
    "route": "/surveys-edit"
  },
  {
    "renderMode": 2,
    "route": "/survey"
  },
  {
    "renderMode": 2,
    "route": "/answer"
  },
  {
    "renderMode": 2,
    "route": "/surveys"
  },
  {
    "renderMode": 2,
    "route": "/recipients"
  },
  {
    "renderMode": 2,
    "redirectTo": "/surveys",
    "route": "/*"
  }
],
  entryPointToBrowserMapping: undefined,
  assets: {
    'index.csr.html': {size: 24109, hash: 'ee7276a9cc7d096259302a1af8a9ad6cc261a23c0361d38008306ac797756e5a', text: () => import('./assets-chunks/index_csr_html.mjs').then(m => m.default)},
    'index.server.html': {size: 17200, hash: '6db723921ca3a2953814d007ce3f15e3ac0b30262bc2e982504e6ed11050cc94', text: () => import('./assets-chunks/index_server_html.mjs').then(m => m.default)},
    'dashboard/survey/index.html': {size: 80272, hash: 'c476bf8a67ecfe37173fd5ffb0aa5c01b0b10e82c39034b06a71fd2f0fd4bc77', text: () => import('./assets-chunks/dashboard_survey_index_html.mjs').then(m => m.default)},
    'surveys-edit/index.html': {size: 80272, hash: 'c476bf8a67ecfe37173fd5ffb0aa5c01b0b10e82c39034b06a71fd2f0fd4bc77', text: () => import('./assets-chunks/surveys-edit_index_html.mjs').then(m => m.default)},
    'dashboard/index.html': {size: 80272, hash: 'c476bf8a67ecfe37173fd5ffb0aa5c01b0b10e82c39034b06a71fd2f0fd4bc77', text: () => import('./assets-chunks/dashboard_index_html.mjs').then(m => m.default)},
    'survey/index.html': {size: 80411, hash: 'd4224df1baa2cdb18b3da2d0cbfeec36f5d56ee4095ccb11221f0d509e40e70a', text: () => import('./assets-chunks/survey_index_html.mjs').then(m => m.default)},
    'answer/index.html': {size: 138847, hash: 'f7bf583dbbc49abecbafa0cd0416b039afbbdc67d975c1bcdd26f2988adf84d5', text: () => import('./assets-chunks/answer_index_html.mjs').then(m => m.default)},
    'recipients/index.html': {size: 80272, hash: 'c476bf8a67ecfe37173fd5ffb0aa5c01b0b10e82c39034b06a71fd2f0fd4bc77', text: () => import('./assets-chunks/recipients_index_html.mjs').then(m => m.default)},
    'surveys/index.html': {size: 212669, hash: 'd5f93fa1ed92164c56aa0a916300c9a71a4bb8fd2586b3841516ecfff7cba92f', text: () => import('./assets-chunks/surveys_index_html.mjs').then(m => m.default)},
    'styles-BDXJXQ5X.css': {size: 20914, hash: 'UzfpVuI31Zw', text: () => import('./assets-chunks/styles-BDXJXQ5X_css.mjs').then(m => m.default)}
  },
};
